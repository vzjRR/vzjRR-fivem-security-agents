#!/usr/bin/env python3
"""Integrity-checked unlocker for sealed vzjRR agent payloads."""
from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import io
import json
import sys
import zipfile
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

CREDIT = "vzjRR Security Assessment for FiveM"
PRODUCT_SALT_PREFIX = b"vzjRR-FiveM-Agent-v1|"
HERE = Path(__file__).resolve().parent


def derive_key(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=PRODUCT_SALT_PREFIX + salt,
        iterations=480_000,
    )
    return base64.urlsafe_b64encode(kdf.derive(passphrase.encode("utf-8")))


def unseal(blob: bytes, passphrase: str) -> bytes:
    if not blob.startswith(b"VZJR1"):
        raise ValueError("Invalid sealed container (magic mismatch)")
    salt = blob[5:21]
    mac = blob[21:53]
    token = blob[53:]
    key = derive_key(passphrase, salt)
    expect = hmac.new(key, salt + token, hashlib.sha256).digest()
    if not hmac.compare_digest(mac, expect):
        raise ValueError("INTEGRITY FAILURE — package was altered or wrong key")
    try:
        return Fernet(key).decrypt(token)
    except InvalidToken as e:
        raise ValueError("Decrypt failed — wrong unlock key or corrupted package") from e


def main() -> int:
    ap = argparse.ArgumentParser(description=f"Unlock sealed agent — {CREDIT}")
    ap.add_argument("--agent", choices=["assessment", "remediation"], required=True)
    ap.add_argument("--key-file", default=str(HERE.parent / "vzjRR_AGENT_UNLOCK_KEY.txt"))
    ap.add_argument("--passphrase", default="")
    ap.add_argument("--outdir", default="")
    args = ap.parse_args()

    sealed = HERE / "protected" / "agent.sealed"
    meta_path = HERE / "protected" / "seal.meta.json"
    if not sealed.exists():
        print("Missing protected/agent.sealed", file=sys.stderr)
        return 2

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    if meta.get("credit") != CREDIT:
        print("Credit watermark mismatch — refusing", file=sys.stderr)
        return 3
    if meta.get("agent") != args.agent:
        print(
            f"This package is agent={meta.get('agent')}, requested={args.agent}",
            file=sys.stderr,
        )
        return 4

    # Optional package-level seal verification
    pkg_hmac = meta.get("package_hmac_sha256")
    if pkg_hmac:
        body = sealed.read_bytes()
        # hmac key material is credit+agent+sha256(passphrase) checked after we have passphrase

    passphrase = args.passphrase.strip()
    if not passphrase:
        kf = Path(args.key_file)
        if not kf.exists():
            print("Provide --passphrase or key file", file=sys.stderr)
            return 5
        for line in kf.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                passphrase = line
                break
    if not passphrase:
        print("Empty passphrase", file=sys.stderr)
        return 5

    raw_sealed = sealed.read_bytes()
    if pkg_hmac:
        chk = hmac.new(
            hashlib.sha256((CREDIT + "|" + args.agent + "|" + passphrase).encode()).digest(),
            raw_sealed,
            hashlib.sha256,
        ).hexdigest()
        if not hmac.compare_digest(chk, pkg_hmac):
            print("PACKAGE HMAC MISMATCH — archive contents altered", file=sys.stderr)
            return 6

    raw = unseal(raw_sealed, passphrase)
    out = Path(args.outdir) if args.outdir else (HERE / "materialized")
    if out.exists():
        for p in sorted(out.rglob("*"), reverse=True):
            if p.is_file():
                p.unlink()
            elif p.is_dir():
                try:
                    p.rmdir()
                except OSError:
                    pass
    out.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(io.BytesIO(raw), "r") as zf:
        for name in zf.namelist():
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError(f"Unsafe member: {name}")
        zf.extractall(out)

    (out / "CREDIT.txt").write_text(
        f"{CREDIT}\nAgent: {args.agent}\nMaterialized integrity: OK\n",
        encoding="utf-8",
    )
    print(f"OK — materialized to {out}")
    print(f"Prepared by: {CREDIT}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        raise SystemExit(1)
