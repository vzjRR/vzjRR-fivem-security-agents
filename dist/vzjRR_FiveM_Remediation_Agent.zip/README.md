# vzjRR_FiveM_Remediation_Agent

**vzjRR Security Assessment for FiveM**

This ZIP contains the **remediation** agent.

## Protection
- Core procedures/scripts are AES-sealed in `protected/agent.sealed`
- HMAC integrity check rejects modified packages
- Unlock requires `vzjRR_AGENT_UNLOCK_KEY.txt` (kept beside the zips)

## Use in Cursor
1. Unzip this archive
2. Copy `CURSOR_SKILL/` to your Cursor skills folder as needed
3. Run `python unlock_and_materialize.py --agent remediation` to extract sealed tools

## Important
Absolute DRM is impossible once unlocked in memory/disk. This packaging makes casual edits break the seal and keeps the core encrypted at rest.
